/**
 ****************************************************************************************
 *
 * @file user_custs1_impl.c
 *
 * @brief Peripheral project Custom1 Server implementation source code.
 *
 * Copyright (C) 2015-2019 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */

#include "gpio.h"
#include "app_api.h"
#include "app.h"
#include "prf_utils.h"
#include "custs1.h"
#include "custs1_task.h"
#include "user_custs1_def.h"
#include "user_custs1_impl.h"
#include "user_peripheral.h"
#include "user_periph_setup.h"
#include "user_config.h"
#include "timer1.h"

// defines
#define POLY_MASK_32 0xB4BCD35C
#define POLY_MASK_31 0x7A5BC2E3

/*
 * GLOBAL VARIABLE DEFINITIONS
 ****************************************************************************************
 */

ke_msg_id_t timer_used      __SECTION_ZERO("retention_mem_area0"); //@RETENTION MEMORY
uint16_t indication_counter __SECTION_ZERO("retention_mem_area0"); //@RETENTION MEMORY
uint16_t non_db_val_counter __SECTION_ZERO("retention_mem_area0"); //@RETENTION MEMORY

bool led_state                                  __SECTION_ZERO("retention_mem_area0"); //@RETENTION MEMORY
bool led2_state                                  __SECTION_ZERO("retention_mem_area0"); //@RETENTION MEMORY
bool led3_state                                  __SECTION_ZERO("retention_mem_area0"); //@RETENTION MEMORY
uint8_t timer1_cnt_ovf                          __SECTION_ZERO("retention_mem_area0"); //@RETENTION MEMORY
uint8_t tick1                                   __SECTION_ZERO("retention_mem_area0"); //@RETENTION MEMORY
uint8_t tick2                                   __SECTION_ZERO("retention_mem_area0"); //@RETENTION MEMORY
uint8_t tick3                                   __SECTION_ZERO("retention_mem_area0"); //@RETENTION MEMORY
uint8_t modes                              __SECTION_ZERO("retention_mem_area0"); //@RETENTION MEMORY
uint32_t lfsr32 __SECTION_ZERO("retention_mem_area0"); //@RETENTION MEMORY
uint32_t lfsr31 __SECTION_ZERO("retention_mem_area0"); //@RETENTION MEMORY


static timer1_count_options_t timer1_config =
{	
	/*Timer1 input clock*/
	.input_clk 	= 	(tim1_clk_src_t)INPUT_CLK,
	
	/*Timer1 free run off*/
	.free_run 	= 	FREE_RUN,
	
	/*Timer1 IRQ mask*/
	.irq_mask	= 	INTERRUPT_MASK_TMR,
	
	/*Timer1 count direction*/
	.count_dir	= 	COUNT_DIRECTION,
	
	/*Timer1 reload value*/
	.reload_val	= 	RELOAD_VALUE
};


/*
 * FUNCTION DEFINITIONS
 ****************************************************************************************
 */

uint32_t lfsr32, lfsr31;


int shift_lfsr(uint32_t *lfsr,  uint32_t polymonial_mask)
{
    int feedback;

    feedback = *lfsr & 1;
    *lfsr >>= 1;
    if (feedback == 1)
        *lfsr ^= polymonial_mask;
    return *lfsr;
}

void init_lfsrs(void)
{
    lfsr32 = 0xABCDE; //seed values
    lfsr31 = 0x23456789;
}

int get_random(void)
{
    /*this random number generator shifts the 32-bit LFSR twice before XORing
      it with the 31-bit LFSR. the bottom 16 bits are used for the random number*/
    shift_lfsr(&lfsr32, POLY_MASK_32);
    return(shift_lfsr(&lfsr32, POLY_MASK_32) ^ shift_lfsr(&lfsr31, POLY_MASK_31));
}


static void toggle_led(void)
{
    if(led_state)
    {
        GPIO_SetInactive(GPIO_PORT_0, GPIO_LED_PIN);
        led_state = false;
    }
    else
    {
        GPIO_SetActive(GPIO_PORT_0, GPIO_LED_PIN);
        led_state = true;
    }
}

static void toggle_led2(void)
{
    if(led2_state)
    {
        GPIO_SetInactive(GPIO_PORT_0, OUT_7_PIN);
        led2_state = false;
    }
    else
    {
        GPIO_SetActive(GPIO_PORT_0, OUT_7_PIN);
        led2_state = true;
    }
}

static void toggle_led3(void)
{
    if(led3_state)
    {
        GPIO_SetInactive(GPIO_PORT_0, OUT_9_PIN);
        led3_state = false;
    }
    else
    {
        GPIO_SetActive(GPIO_PORT_0, OUT_9_PIN);
        led3_state = true;
    }
}


static void user_timer_wakeup_ble(void)
{
    // BLE awake via timer 1
}




static void timer1_overflow(void)
{
    int r;
    if (timer1_cnt_ovf == TIMER1_OVF_COUNTER)
    {
        r = get_random();
        
        if (tick1==0) {
            switch(modes & 0x03) {
                case 0:
                    GPIO_SetInactive(GPIO_PORT_0, GPIO_LED_PIN);
                    led_state = false;
                    break;
                case 1:
                    toggle_led();
                    tick1 = 1 + (r & 0x0f);
                    break;
                case 2:
                    toggle_led();
                    tick1 = 10;
                    break;
                case 3:
                    GPIO_SetActive(GPIO_PORT_0, GPIO_LED_PIN);
                    led_state = true;
                    break;
                default:
                    break;   
            }
        } 
        
        if (tick2==0) {
            switch((modes & 0x0c)>>2) {
                case 0:
                    GPIO_SetInactive(GPIO_PORT_0, OUT_7_PIN);
                    led2_state = false;
                    break;
                case 1:
                    toggle_led2();
                    tick2 = 1 + ((r>>4) & 0x07);
                    break;
                case 2:
                    toggle_led2();
                    tick2 = 10;
                    break;
                case 3:
                    GPIO_SetActive(GPIO_PORT_0, OUT_7_PIN);
                    led2_state = true;
                    break;
                default:
                    break;   
            }
        } 
        
        if (tick3==0) {
            switch((modes & 0x30)>>4) {
                case 0:
                    GPIO_SetInactive(GPIO_PORT_0, OUT_9_PIN);
                    led3_state = false;
                    break;
                case 1:
                    toggle_led3();
                    tick3 = 1 + ((r>>8) & 0x07);
                    break;
                case 2:
                    toggle_led3();
                    tick3 = 6;
                    break;
                case 3:
                    GPIO_SetActive(GPIO_PORT_0, OUT_9_PIN);
                    led3_state = true;
                    break;
                default:
                    break;   
            }
        } 

            
        tick1--;
        tick2--;
        tick3--;
        
        //toggle_led();
        
        timer1_cnt_ovf = 0;
        /* Wake up the device and print out the measured time */
        //arch_ble_force_wakeup();                // Force the BLE to wake up
        //app_easy_wakeup_set(user_timer_wakeup_ble);
        //app_easy_wakeup();                      // Send the message to print
    }
    
    timer1_cnt_ovf++;
}


void timer1_initialize(void)
{
    /*Enable PD_TIM power domain*/
	SetBits16(PMU_CTRL_REG, TIM_SLEEP, 0);                  // Enable the PD_TIM
    timer1_count_config(&timer1_config, timer1_overflow);   // Set the capture counting configurations for the timer

    led_state = false;
    init_lfsrs();
    modes = 0x27;
    tick1 = 0;
    tick2 = 0;
    tick3 = 0;

}


void user_svc1_ctrl_wr_ind_handler(ke_msg_id_t const msgid,
                                      struct custs1_val_write_ind const *param,
                                      ke_task_id_t const dest_id,
                                      ke_task_id_t const src_id)
{
    uint8_t val = 0;
    memcpy(&val, &param->value[0], param->length);

    if (val != CUSTS1_CP_ADC_VAL1_DISABLE)
    {
        timer_used = app_easy_timer(APP_PERIPHERAL_CTRL_TIMER_DELAY, app_adcval1_timer_cb_handler);
    }
    else
    {
        if (timer_used != EASY_TIMER_INVALID_TIMER)
        {
            app_easy_timer_cancel(timer_used);
            timer_used = EASY_TIMER_INVALID_TIMER;
        }
    }
}

void user_svc1_led_wr_ind_handler(ke_msg_id_t const msgid,
                                     struct custs1_val_write_ind const *param,
                                     ke_task_id_t const dest_id,
                                     ke_task_id_t const src_id)
{
    uint8_t val = 0;
    memcpy(&val, &param->value[0], param->length);
    
    
    modes = val;
    tick1 = 0;
    tick2 = 0;
    tick3 = 0;

#ifdef JUNK
    if (val == CUSTS1_LED_ON)
    {
        GPIO_SetActive(GPIO_LED_PORT, GPIO_LED_PIN);
    }
    else if (val == CUSTS1_LED_OFF)
    {
        GPIO_SetInactive(GPIO_LED_PORT, GPIO_LED_PIN);
    }
#endif
}

void user_svc1_long_val_cfg_ind_handler(ke_msg_id_t const msgid,
                                           struct custs1_val_write_ind const *param,
                                           ke_task_id_t const dest_id,
                                           ke_task_id_t const src_id)
{
    // Generate indication when the central subscribes to it
    if (param->value[0])
    {
        uint8_t conidx = KE_IDX_GET(src_id);

        struct custs1_val_ind_req* req = KE_MSG_ALLOC_DYN(CUSTS1_VAL_IND_REQ,
                                                          prf_get_task_from_id(TASK_ID_CUSTS1),
                                                          TASK_APP,
                                                          custs1_val_ind_req,
                                                          sizeof(indication_counter));

        req->conidx = app_env[conidx].conidx;
        req->handle = SVC1_IDX_INDICATEABLE_VAL;
        req->length = sizeof(indication_counter);
        req->value[0] = (indication_counter >> 8) & 0xFF;
        req->value[1] = indication_counter & 0xFF;

        indication_counter++;

        ke_msg_send(req);
    }
}

void user_svc1_long_val_wr_ind_handler(ke_msg_id_t const msgid,
                                          struct custs1_val_write_ind const *param,
                                          ke_task_id_t const dest_id,
                                          ke_task_id_t const src_id)
{
}

void user_svc1_long_val_ntf_cfm_handler(ke_msg_id_t const msgid,
                                           struct custs1_val_write_ind const *param,
                                           ke_task_id_t const dest_id,
                                           ke_task_id_t const src_id)
{
}

void user_svc1_adc_val_1_cfg_ind_handler(ke_msg_id_t const msgid,
                                            struct custs1_val_write_ind const *param,
                                            ke_task_id_t const dest_id,
                                            ke_task_id_t const src_id)
{
}

void user_svc1_adc_val_1_ntf_cfm_handler(ke_msg_id_t const msgid,
                                            struct custs1_val_write_ind const *param,
                                            ke_task_id_t const dest_id,
                                            ke_task_id_t const src_id)
{
}

void user_svc1_button_cfg_ind_handler(ke_msg_id_t const msgid,
                                         struct custs1_val_write_ind const *param,
                                         ke_task_id_t const dest_id,
                                         ke_task_id_t const src_id)
{
}

void user_svc1_button_ntf_cfm_handler(ke_msg_id_t const msgid,
                                         struct custs1_val_write_ind const *param,
                                         ke_task_id_t const dest_id,
                                         ke_task_id_t const src_id)
{
}

void user_svc1_indicateable_cfg_ind_handler(ke_msg_id_t const msgid,
                                               struct custs1_val_write_ind const *param,
                                               ke_task_id_t const dest_id,
                                               ke_task_id_t const src_id)
{
}

void user_svc1_indicateable_ind_cfm_handler(ke_msg_id_t const msgid,
                                               struct custs1_val_write_ind const *param,
                                               ke_task_id_t const dest_id,
                                               ke_task_id_t const src_id)
{
}

void user_svc1_long_val_att_info_req_handler(ke_msg_id_t const msgid,
                                                struct custs1_att_info_req const *param,
                                                ke_task_id_t const dest_id,
                                                ke_task_id_t const src_id)
{
    struct custs1_att_info_rsp *rsp = KE_MSG_ALLOC(CUSTS1_ATT_INFO_RSP,
                                                   src_id,
                                                   dest_id,
                                                   custs1_att_info_rsp);
    // Provide the connection index.
    rsp->conidx  = app_env[param->conidx].conidx;
    // Provide the attribute index.
    rsp->att_idx = param->att_idx;
    // Provide the current length of the attribute.
    rsp->length  = 0;
    // Provide the ATT error code.
    rsp->status  = ATT_ERR_NO_ERROR;

    ke_msg_send(rsp);
}

void user_svc1_rest_att_info_req_handler(ke_msg_id_t const msgid,
                                            struct custs1_att_info_req const *param,
                                            ke_task_id_t const dest_id,
                                            ke_task_id_t const src_id)
{
    struct custs1_att_info_rsp *rsp = KE_MSG_ALLOC(CUSTS1_ATT_INFO_RSP,
                                                   src_id,
                                                   dest_id,
                                                   custs1_att_info_rsp);
    // Provide the connection index.
    rsp->conidx  = app_env[param->conidx].conidx;
    // Provide the attribute index.
    rsp->att_idx = param->att_idx;
    // Force current length to zero.
    rsp->length  = 0;
    // Provide the ATT error code.
    rsp->status  = ATT_ERR_WRITE_NOT_PERMITTED;

    ke_msg_send(rsp);
}

void app_adcval1_timer_cb_handler()
{
    struct custs1_val_ntf_ind_req *req = KE_MSG_ALLOC_DYN(CUSTS1_VAL_NTF_REQ,
                                                          prf_get_task_from_id(TASK_ID_CUSTS1),
                                                          TASK_APP,
                                                          custs1_val_ntf_ind_req,
                                                          DEF_SVC1_ADC_VAL_1_CHAR_LEN);

    // ADC value to be sampled
    static uint16_t sample      __SECTION_ZERO("retention_mem_area0");
    sample = (sample <= 0xffff) ? (sample + 1) : 0;

    //req->conhdl = app_env->conhdl;
    req->handle = SVC1_IDX_ADC_VAL_1_VAL;
    req->length = DEF_SVC1_ADC_VAL_1_CHAR_LEN;
    req->notification = true;
    memcpy(req->value, &sample, DEF_SVC1_ADC_VAL_1_CHAR_LEN);

    ke_msg_send(req);

    if (ke_state_get(TASK_APP) == APP_CONNECTED)
    {
        // Set it once again until Stop command is received in Control Characteristic
        timer_used = app_easy_timer(APP_PERIPHERAL_CTRL_TIMER_DELAY, app_adcval1_timer_cb_handler);
    }
}

void user_svc3_read_non_db_val_handler(ke_msg_id_t const msgid,
                                           struct custs1_value_req_ind const *param,
                                           ke_task_id_t const dest_id,
                                           ke_task_id_t const src_id)
{
    // Increase value by one
    non_db_val_counter++;

    struct custs1_value_req_rsp *rsp = KE_MSG_ALLOC_DYN(CUSTS1_VALUE_REQ_RSP,
                                                        prf_get_task_from_id(TASK_ID_CUSTS1),
                                                        TASK_APP,
                                                        custs1_value_req_rsp,
                                                        DEF_SVC3_READ_VAL_4_CHAR_LEN);

    // Provide the connection index.
    rsp->conidx  = app_env[param->conidx].conidx;
    // Provide the attribute index.
    rsp->att_idx = param->att_idx;
    // Force current length to zero.
    rsp->length  = sizeof(non_db_val_counter);
    // Provide the ATT error code.
    rsp->status  = ATT_ERR_NO_ERROR;
    // Copy value
    memcpy(&rsp->value, &non_db_val_counter, rsp->length);
    // Send message
    ke_msg_send(rsp);
}
